if __name__ == '__main__':
    with open('classdata.json','r') as file:
        dic = file.read()
    print(str(dic))